package carballo.jesus.peliculas

class Pelicula (val id:Int, val nombre:String, val sipnosis:String, val dur:Int, val img:Int) {
}