package carballo.jesus.peliculas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    var peliculas: ArrayList<Pelicula> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        llenar_Peliculas()
        var adapter=AdaptadorMovies(this,peliculas)
        var listView: ListView = findViewById(R.id.listv)
        listView.adapter=adapter
    }

    fun llenar_Peliculas(){
        val pelicula1=Pelicula(1,"El Exorcismo de Dios","La historia de \"El Exorcismo de Dios\" sigue al padre \"Peter Williams\", un exorcista estadounidense que, al estar poseído por un demonio que intentaba expulsar, termina cometiendo el más terrible sacrilegio. Dieciocho años más tarde, las consecuencias de su pecado volverán a perseguirlo, desatando la mayor batalla contra el mal interior.",98, R.drawable.ic_launcher_background)
        peliculas.add(pelicula1)
        val pelicula2=Pelicula(2,"Sing 2 ¡Ven y Canta de Nuevo!","En esta época decembrina, llega el nuevo capítulo de la exitosa franquicia animada de Illumination, cargada de grandes sueños y espectaculares éxitos musicales. El koala, Buster Moon, y su elenco de estrellas se preparan para lanzar sobre el escenario su actuación más extravagante y deslumbrante hasta la fecha, ¡y nada menos que, en la capital mundial del entretenimiento! Solo hay un pequeño inconveniente: primero tienen que persuadir para unirse a ellos a la estrella de rock más solitario y huraño del mundo, interpretada por el legendario ícono de la música Bono, quien hará su debut cinematográfico de animación.",110, R.drawable.ic_launcher_background)
        peliculas.add(pelicula2)
        val pelicula3=Pelicula(3,"Corazón de Fuego","Nueva York, 1920. Georgia Nolan sueña con ser la primera mujer bombero del mundo, pero todos quieren convencerla de que esa no es una profesión para chicas. Cuando, años más tarde, un misterioso pirómano comienza a sembrar el pánico en Broadway, surgirá la oportunidad que siempre ha estado esperando. La investigación es asignada al bombero retirado Shawn, el padre de Georgia. Desesperada por ayudar a su padre y salvar su ciudad, Georgia se disfraza de chico y se une a un pequeño grupo de bomberos inadaptados que van a poner todo su corazón en detener al pirómano.",93, R.drawable.ic_launcher_background)
        peliculas.add(pelicula3)
        val pelicula4=Pelicula(4,"Digimon Adventure: La Última Evolución Kizuna","Ocurre un fenómeno sin precedentes y los Niños Elegidos descubren que crecer significa el fin de su conexión con sus Digimon. Además de eso, los Elegidos se dan cuenta que cuanto mas luchan con su Digimon, mas rápido se rompe su vínculo. ¿Lucharan por los demás arriesgándose a perder? El momento de elegir y decidir se acerca rápidamente. Tai, Agumon y los demás, se verán obligados a arriesgarlo todo en su última aventura épica.",95, R.drawable.ic_launcher_background)
        peliculas.add(pelicula4)
        val pelicula5=Pelicula(5,"Batman","El director Matt Reeves (películas de “El Planeta de los Simios”) está al frente con Robert Pattinson (“Tenet”, “El Faro”, “Good Time: Viviendo al Límite”) quien protagoniza a Batman —el detective vigilante de Ciudad Gótica— y a el multimillonario Bruce Wayne.\n",176, R.drawable.ic_launcher_background)
        peliculas.add(pelicula5)

    }

}